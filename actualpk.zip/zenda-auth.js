// ============================================================
// ZENDA — Módulo de Autenticación y Seguridad
// Incluir en todas las páginas protegidas con:
// <script src="zenda-auth.js"></script>
// ============================================================

const SUPA_URL = 'https://vmgldwpbtsfxweokzbmf.supabase.co';
const SUPA_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZtZ2xkd3BidHNmeHdlb2t6Ym1mIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI5ODYwMTUsImV4cCI6MjA4ODU2MjAxNX0.9EuUv3VFQSAka0kvKoZMYcux1667K3x5ZpvG7bRQUmQ';

// ── Instancia global del cliente Supabase
const db = window.supabase.createClient(SUPA_URL, SUPA_KEY);

// ── Estado global del usuario autenticado
window.ZendaAuth = {
  user: null,       // objeto auth de Supabase
  perfil: null,     // row de tabla `usuarios`
  negocio: null,    // row de tabla `negocios`
  rol: null,        // 'superadmin' | 'admin' | 'medico' | 'recepcion'
  db: db,           // cliente compartido

  // ── Inicializar sesión y cargar perfil
  async init(rolesPermitidos = []) {
    try {
      const { data: { session }, error } = await db.auth.getSession();

      if (error || !session) {
        this._redirectLogin();
        return false;
      }

      this.user = session.user;

      // Cargar perfil del usuario desde tabla `usuarios`
      const { data: perfil, error: pErr } = await db
        .from('usuarios')
        .select('*, negocios(*)')
        .eq('auth_id', this.user.id)
        .maybeSingle();

      if (pErr || !perfil) {
        console.error('Sin perfil de usuario:', pErr?.message);
        this._redirectLogin('Sin perfil asignado. Contacta al administrador.');
        return false;
      }

      this.perfil  = perfil;
      this.rol     = perfil.rol;
      this.negocio = perfil.negocios || null;

      // Verificar rol permitido
      if (rolesPermitidos.length > 0 && !rolesPermitidos.includes(this.rol)) {
        this._redirectUnauthorized();
        return false;
      }

      // Verificar negocio activo (excepto superadmin)
      if (this.rol !== 'superadmin' && this.negocio?.estado !== 'activo') {
        this._redirectLogin('Tu cuenta está pendiente de aprobación.');
        return false;
      }

      console.log(`✅ ZendaAuth: ${perfil.nombre} [${this.rol}]`);
      return true;

    } catch (e) {
      console.error('ZendaAuth.init error:', e);
      this._redirectLogin();
      return false;
    }
  },

  // ── Cerrar sesión
  async logout() {
    await db.auth.signOut();
    localStorage.removeItem('zenda_session_hint');
    window.location.href = 'zenda-login.html';
  },

  // ── Redirigir al login con mensaje opcional
  _redirectLogin(msg = '') {
    if (msg) sessionStorage.setItem('zenda_login_msg', msg);
    window.location.href = 'zenda-login.html';
  },

  // ── Redirigir a página de acceso denegado
  _redirectUnauthorized() {
    sessionStorage.setItem('zenda_login_msg', 'No tienes permiso para acceder a esta página.');
    window.location.href = 'zenda-login.html';
  },

  // ── Escuchar cambios de sesión en tiempo real
  onAuthChange(callback) {
    db.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_OUT') {
        window.location.href = 'zenda-login.html';
      }
      if (callback) callback(event, session);
    });
  },

  // ── Helpers de rol
  isSuperAdmin() { return this.rol === 'superadmin'; },
  isAdmin()      { return this.rol === 'admin' || this.rol === 'superadmin'; },
  isMedico()     { return this.rol === 'medico'; },

  // ── Obtener nombre para mostrar en UI
  getNombre()    { return this.perfil?.nombre || this.user?.email || 'Usuario'; },
  getNegocioId() { return this.perfil?.negocio_id || null; },
};
